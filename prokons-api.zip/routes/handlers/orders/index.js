const create = require('./create');

module.exports = {
  create,
};
