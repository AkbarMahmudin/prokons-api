const create = require('./create');
const getToken = require('./getToken');

module.exports = {
  create, getToken,
};
