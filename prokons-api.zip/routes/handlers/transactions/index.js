const getTransaction = require('./getTransaction');
const getTransactions = require('./getTransactions');

module.exports = {
  getTransaction,
  getTransactions,
};
